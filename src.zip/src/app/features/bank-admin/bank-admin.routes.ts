// src/app/features/bank-admin/bank-admin.routes.ts
import { Routes } from '@angular/router';

export const BANK_ADMIN_ROUTES: Routes = [
  {
    path: '',
    // A layout/shell component for the admin section
    loadComponent: () => import('./bank-admin'),
    children: [
      {
        path: 'organizations',
        loadComponent: () => import('./pages/organization-list/organization-list'),
      },
      {
        path: 'organizations/:id',
        loadComponent: () => import('./pages/organization-detail/organization-detail'),
      },
      {
        path: 'organizations/:id/documents', // The 'id' is the organizationId
        loadComponent: () => import('./pages/organization-documents/organization-documents'),
      },

      {
        path: 'notifications',
        loadComponent: () => import('./pages/notifications/notifications'),
      },
      {
        path: 'organizations/:orgId/accounts',
        loadComponent: () => import('./pages/bank-account-list/bank-account-list'),
      },
      {
        path: 'organizations/:orgId/accounts/:accountId',
        loadComponent: () => import('./pages/bank-account-detail/bank-account-detail'),
      },
      {
        path: 'organizations/:orgId/requests',
        loadComponent: () => import('./pages/pending-requests/pending-requests'),
      },
    //   {
    //     path: 'settings',
    //     loadComponent: () => import('./pages/settings/settings.component'),
    //   },
      {
        path: '',
        redirectTo: 'organizations',
        pathMatch: 'full',
      },
    ],
  },
];